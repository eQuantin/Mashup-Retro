﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlateformMovement : MonoBehaviour
{
    float dirX;
    float moveSpeed = 5f;
    bool moveRight = true;

    // Update is called once per frame
    void Update()
    {
        if (transform.position.x < 7) {
            moveRight = true;
        }
        if (transform.position.x > 18)
            moveRight = false;

        if (moveRight)
            transform.position = new Vector2(transform.position.x + moveSpeed * Time.deltaTime, transform.position.y + moveSpeed * Time.deltaTime);
        else
            transform.position = new Vector2(transform.position.x - moveSpeed * Time.deltaTime, transform.position.y - moveSpeed * Time.deltaTime);
    }
}
